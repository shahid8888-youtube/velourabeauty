import { cn } from "@/lib/utils";

export function Badge({
  children,
  tone = "rose",
  className,
}: {
  children: React.ReactNode;
  tone?: "rose" | "gold" | "dark";
  className?: string;
}) {
  const tones: Record<string, string> = {
    rose: "bg-blush text-deeprose",
    gold: "bg-[#F4EAD5] text-[#8A6A2F]",
    dark: "bg-espresso text-ivory",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center px-2.5 py-1 rounded-full text-[11px] tracking-wide font-medium font-body",
        tones[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

export function StarRating({ rating, size = 13 }: { rating: number; size?: number }) {
  return (
    <div className="flex items-center gap-0.5" role="img" aria-label={`Rated ${rating} out of 5`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <svg
          key={n}
          width={size}
          height={size}
          viewBox="0 0 24 24"
          fill={n <= Math.round(rating) ? "#C9A66B" : "none"}
          stroke="#C9A66B"
          strokeWidth={1.5}
        >
          <polygon points="12 2 15 9 22 9.3 16.5 14 18.3 21 12 17.3 5.7 21 7.5 14 2 9.3 9 9" />
        </svg>
      ))}
    </div>
  );
}
