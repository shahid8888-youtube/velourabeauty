"use client";

import { cn } from "@/lib/utils";
import { ButtonHTMLAttributes, forwardRef } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "solid" | "rose" | "outline" | "ghost";
  size?: "sm" | "md" | "lg";
}

const variants: Record<string, string> = {
  solid: "bg-espresso text-ivory hover:shadow-lg",
  rose: "bg-rosegold text-ivory hover:shadow-lg",
  outline: "bg-transparent border border-espresso text-espresso hover:bg-espresso hover:text-ivory",
  ghost: "bg-transparent text-espresso hover:bg-ivory-deep",
};

const sizes: Record<string, string> = {
  sm: "px-5 py-2 text-[12px]",
  md: "px-8 py-3.5 text-[13px]",
  lg: "px-10 py-4 text-[14px]",
};

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "solid", size = "md", children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "relative overflow-hidden font-body tracking-[0.1em] uppercase transition-all duration-300 hover:-translate-y-0.5 disabled:opacity-50 disabled:pointer-events-none group/btn",
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      >
        <span className="relative z-10 flex items-center justify-center gap-2">{children}</span>
        <span className="pointer-events-none absolute inset-y-0 -left-1/2 w-1/3 opacity-0 group-hover/btn:opacity-100 group-hover/btn:animate-shimmer bg-gradient-to-r from-transparent via-white/30 to-transparent" />
      </button>
    );
  }
);
Button.displayName = "Button";

export default Button;
