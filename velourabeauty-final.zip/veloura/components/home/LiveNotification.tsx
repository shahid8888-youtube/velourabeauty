"use client";

import { useEffect, useState } from "react";
import { ShoppingBag } from "lucide-react";

const liveOrders = [
  "Ayesha in Lahore just ordered Velvet Silk Serum",
  "Zainab in Karachi just ordered Rose Gold Lip Duo",
  "Hassan in Islamabad just ordered Overnight Renewal Cream",
  "Mahnoor in Faisalabad just ordered Champagne Highlight Balm",
  "Sana in Multan just ordered Silk Bloom Hair Oil",
];

export default function LiveNotification() {
  const [idx, setIdx] = useState(0);
  const [show, setShow] = useState(false);

  useEffect(() => {
    const showTimer = setTimeout(() => setShow(true), 2500);
    const cycle = setInterval(() => {
      setShow(false);
      setTimeout(() => {
        setIdx((i) => (i + 1) % liveOrders.length);
        setShow(true);
      }, 500);
    }, 6500);
    return () => { clearTimeout(showTimer); clearInterval(cycle); };
  }, []);

  return (
    <div
      className="fixed bottom-6 left-6 z-30 hidden sm:flex items-center gap-3 pr-5 pl-3 py-3 rounded-full shadow-xl max-w-xs bg-ivory border border-line transition-all duration-500"
      style={{
        opacity: show ? 1 : 0,
        transform: show ? "translateY(0)" : "translateY(12px)",
        pointerEvents: show ? "auto" : "none",
      }}
    >
      <span className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 bg-blush">
        <ShoppingBag size={14} className="text-deeprose" />
      </span>
      <p className="text-[11.5px] leading-snug font-body text-espresso">
        {liveOrders[idx]} <span className="text-espresso-soft">· 2 min ago</span>
      </p>
    </div>
  );
}
