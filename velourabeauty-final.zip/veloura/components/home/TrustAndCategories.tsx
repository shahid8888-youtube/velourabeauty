import Image from "next/image";
import Link from "next/link";
import { Truck, ShieldCheck, RotateCcw, Sparkles, ArrowRight } from "lucide-react";
import Reveal from "@/components/ui/Reveal";

const trustItems = [
  { icon: Truck, label: "Free shipping over $75" },
  { icon: ShieldCheck, label: "Dermatologist tested" },
  { icon: RotateCcw, label: "30-day returns" },
  { icon: Sparkles, label: "Cruelty-free & vegan formulas" },
];

const categories = [
  { name: "Skincare", desc: "Rituals for radiant skin", href: "/shop/skincare", img: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=800&auto=format&fit=crop" },
  { name: "Makeup", desc: "Colour, undiluted", href: "/shop/makeup", img: "https://images.unsplash.com/photo-1583241800698-9c2e9e6f8f8f?q=80&w=800&auto=format&fit=crop" },
  { name: "Haircare", desc: "Strength meets shine", href: "/shop/haircare", img: "https://images.unsplash.com/photo-1522338242992-e1a54906a8da?q=80&w=800&auto=format&fit=crop" },
  { name: "Fragrance", desc: "Signature scents", href: "/shop/fragrance", img: "https://images.unsplash.com/photo-1541643600914-78b084683601?q=80&w=800&auto=format&fit=crop" },
];

export function TrustBar() {
  return (
    <div className="bg-ivory-deep border-y border-line">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-6 grid grid-cols-2 md:grid-cols-4 gap-6">
        {trustItems.map(({ icon: Icon, label }, i) => (
          <Reveal key={i} delay={i * 80} className="flex items-center gap-3">
            <Icon size={20} className="text-rosegold" strokeWidth={1.5} />
            <span className="text-[12.5px] leading-tight font-body text-espresso">{label}</span>
          </Reveal>
        ))}
      </div>
    </div>
  );
}

export function Categories() {
  return (
    <section className="max-w-7xl mx-auto px-5 sm:px-8 py-20">
      <Reveal className="flex items-end justify-between mb-7">
        <div>
          <p className="text-[12px] uppercase tracking-[0.25em] mb-2 font-body text-rosegold">Shop by category</p>
          <h2 className="text-[28px] sm:text-[34px] leading-tight font-display text-espresso">Find your ritual</h2>
        </div>
      </Reveal>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
        {categories.map((c, i) => (
          <Reveal key={c.name} delay={i * 90}>
            <Link href={c.href} className="relative group block overflow-hidden rounded-sm shadow-md hover:shadow-xl transition-shadow duration-500" style={{ aspectRatio: "3/4" }}>
              <Image src={c.img} alt={c.name} fill sizes="280px" className="object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-espresso/70 to-espresso/5" />
              <div className="absolute bottom-5 left-5 right-5">
                <h3 className="font-display text-[19px] text-ivory">{c.name}</h3>
                <p className="font-body text-[12px] mt-0.5 text-blush">{c.desc}</p>
                <span className="inline-flex items-center gap-1 mt-2 text-[11px] opacity-0 group-hover:opacity-100 transition-opacity font-body text-champagne">
                  Explore <ArrowRight size={12} />
                </span>
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
