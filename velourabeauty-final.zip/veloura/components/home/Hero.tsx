"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Sparkles, ArrowRight } from "lucide-react";
import Button from "@/components/ui/Button";
import { StarRating } from "@/components/ui/Badge";

const words = ["undiluted.", "unhurried.", "unmistakable."];

export default function Hero() {
  const [wordIdx, setWordIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setWordIdx((i) => (i + 1) % words.length), 2600);
    return () => clearInterval(t);
  }, []);

  return (
    <section className="relative overflow-hidden bg-ivory">
      <div className="absolute -top-32 -right-32 w-[420px] h-[420px] rounded-full pointer-events-none opacity-40 hidden md:block bg-[radial-gradient(circle,#F1DFDA,transparent_70%)]" />
      <div className="max-w-7xl mx-auto px-5 sm:px-8 grid md:grid-cols-2 items-center gap-10 py-12 md:py-0 md:h-[660px] relative">
        <div className="order-2 md:order-1 relative z-10">
          <p className="text-[12px] uppercase tracking-[0.3em] mb-5 flex items-center gap-2 font-body text-rosegold">
            <Sparkles size={13} /> The Radiance Edit — New Season
          </p>
          <h1 className="leading-[1.05] font-display text-espresso" style={{ fontSize: "clamp(40px, 6vw, 68px)", fontWeight: 500 }}>
            Beauty, <span key={wordIdx} className="italic text-rosegold inline-block">{words[wordIdx]}</span>
          </h1>
          <p className="mt-6 max-w-md text-[15px] leading-relaxed font-body text-espresso-soft">
            Formulated in small batches, tested for every skin tone, and shipped
            to your door. Veloura is skincare and colour cosmetics built for how
            skin actually behaves — not how a lab thinks it should.
          </p>
          <div className="mt-9 flex items-center gap-4 flex-wrap">
            <Link href="/shop"><Button variant="solid">Shop the Edit <ArrowRight size={14} /></Button></Link>
            <Link href="/quiz"><Button variant="outline">Take the Skin Quiz</Button></Link>
          </div>
          <div className="mt-10 flex items-center gap-6">
            <StarRating rating={4.8} size={15} />
            <span className="text-[13px] font-body text-espresso-soft">4.8/5 from 18,400+ reviews</span>
          </div>
        </div>
        <div className="order-1 md:order-2 relative h-[380px] md:h-[560px] rounded-sm overflow-hidden shadow-2xl">
          <Image
            src="https://images.unsplash.com/photo-1596462502278-27bfdc403348?q=80&w=1200&auto=format&fit=crop"
            alt="Veloura hero product"
            fill
            priority
            className="object-cover animate-kenburns"
          />
          <div className="absolute bottom-5 left-5 right-5 sm:right-auto sm:w-64 p-4 rounded-sm bg-ivory/90 backdrop-blur-sm">
            <p className="text-[11px] uppercase tracking-widest mb-1 font-body text-rosegold">Bestseller</p>
            <p className="font-display text-[15px] text-espresso">Velvet Silk Serum</p>
            <p className="font-body text-[13px] mt-0.5 text-espresso-soft">$68 · Sold every 40 seconds</p>
          </div>
          <div className="absolute top-5 right-5 px-3 py-2 rounded-full flex items-center gap-2 shadow-lg bg-ivory/92 animate-floaty">
            <span className="w-2 h-2 rounded-full bg-[#5C8A6B]" />
            <span className="text-[11px] font-body text-espresso">312 bought this month</span>
          </div>
        </div>
      </div>
    </section>
  );
}
