"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import Reveal from "@/components/ui/Reveal";
import Button from "@/components/ui/Button";
import { toast } from "sonner";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    toast.success("Welcome to Veloura — check your inbox for 15% off!");
    setEmail("");
  };
  return (
    <section className="py-20 relative overflow-hidden bg-espresso">
      <div className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full opacity-[0.08] pointer-events-none bg-rosegold" />
      <Reveal className="max-w-xl mx-auto px-5 text-center relative">
        <p className="text-[12px] uppercase tracking-[0.3em] mb-3 font-body text-champagne">Join the list</p>
        <h2 className="font-display text-[30px] text-ivory">Get 15% off your first order</h2>
        <p className="font-body text-[14px] mt-3 text-[#C9BEB6]">Early access to launches, restocks, and members-only rituals.</p>
        <form onSubmit={handleSubmit} className="mt-7 flex gap-2">
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Your email address"
            className="flex-1 px-4 py-3 text-[13px] outline-none font-body bg-ivory/[0.08] text-ivory border border-ivory/25 focus:ring-1 focus:ring-rosegold transition-shadow"
          />
          <Button variant="rose" type="submit" className="px-6 py-3">Subscribe</Button>
        </form>
      </Reveal>
    </section>
  );
}

const faqs = [
  { q: "Is Veloura cruelty-free?", a: "Yes — every formula is developed without animal testing, and the majority of our line is vegan. Vegan status is noted on each product page." },
  { q: "Do you offer cash on delivery in Pakistan?", a: "Yes, COD is available across Pakistan alongside card and wallet payments, and you can also order directly over WhatsApp." },
  { q: "What is your return policy?", a: "Unopened products can be returned within 30 days of delivery for a full refund. See our Refund Policy for details." },
];

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-line">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between py-5 text-left" aria-expanded={open}>
        <span className="font-display text-[16px] text-espresso">{q}</span>
        <span className="transition-transform duration-300" style={{ transform: open ? "rotate(45deg)" : "rotate(0deg)" }}>
          <Plus size={16} className="text-rosegold" />
        </span>
      </button>
      <div style={{ maxHeight: open ? "200px" : "0px", overflow: "hidden", transition: "max-height 0.4s ease" }}>
        <p className="font-body text-[14px] pb-5 leading-relaxed pr-8 text-espresso-soft">{a}</p>
      </div>
    </div>
  );
}

export function FAQ() {
  return (
    <section className="max-w-3xl mx-auto px-5 sm:px-8 py-20">
      <Reveal className="mb-7">
        <p className="text-[12px] uppercase tracking-[0.25em] mb-2 font-body text-rosegold">Good to know</p>
        <h2 className="text-[28px] sm:text-[34px] leading-tight font-display text-espresso">Frequently asked questions</h2>
      </Reveal>
      <Reveal>{faqs.map((f, i) => <FAQItem key={i} {...f} />)}</Reveal>
    </section>
  );
}
