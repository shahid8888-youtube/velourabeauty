"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import Reveal from "@/components/ui/Reveal";
import ProductScrollRow from "@/components/product/ProductScrollRow";
import Button from "@/components/ui/Button";
import { Product } from "@/lib/types";

export function BestSellers({ products }: { products: Product[] }) {
  return (
    <section className="max-w-7xl mx-auto px-5 sm:px-8 py-4">
      <Reveal className="flex items-end justify-between mb-7">
        <div>
          <p className="text-[12px] uppercase tracking-[0.25em] mb-2 font-body text-rosegold">Loved on repeat</p>
          <h2 className="text-[28px] sm:text-[34px] leading-tight font-display text-espresso">Best sellers</h2>
        </div>
        <Link href="/shop" className="hidden sm:flex items-center gap-1.5 text-[13px] tracking-wide pb-1 border-b border-espresso hover:gap-2.5 transition-all font-body text-espresso">
          View all <ArrowRight size={14} />
        </Link>
      </Reveal>
      <Reveal delay={100}>
        <ProductScrollRow products={products} />
      </Reveal>
    </section>
  );
}

export function FlashSale() {
  const [time, setTime] = useState({ h: 14, m: 32, s: 9 });
  useEffect(() => {
    const t = setInterval(() => {
      setTime((prev) => {
        let { h, m, s } = prev;
        s -= 1;
        if (s < 0) { s = 59; m -= 1; }
        if (m < 0) { m = 59; h -= 1; }
        if (h < 0) { h = 0; m = 0; s = 0; }
        return { h, m, s };
      });
    }, 1000);
    return () => clearInterval(t);
  }, []);
  const pad = (n: number) => String(n).padStart(2, "0");

  return (
    <section className="py-16 relative overflow-hidden bg-espresso">
      <div className="absolute inset-0 opacity-[0.06] pointer-events-none bg-[radial-gradient(circle_at_20%_50%,#C9A66B,transparent_40%)]" />
      <Reveal className="max-w-7xl mx-auto px-5 sm:px-8 flex flex-col md:flex-row items-center justify-between gap-6 relative">
        <div>
          <p className="text-[12px] uppercase tracking-[0.3em] mb-2 font-body text-champagne">Ends soon</p>
          <h2 className="font-display text-[30px] text-ivory">Flash Sale — up to 40% off</h2>
        </div>
        <div className="flex items-center gap-3">
          {([["h", time.h], ["m", time.m], ["s", time.s]] as const).map(([label, val]) => (
            <div key={label} className="w-16 h-16 flex flex-col items-center justify-center rounded-sm bg-ivory/[0.08] border border-ivory/10">
              <span className="font-display text-[22px] tabular-nums text-ivory">{pad(val)}</span>
              <span className="font-body text-[9px] uppercase tracking-widest text-champagne">{label === "h" ? "hrs" : label === "m" ? "min" : "sec"}</span>
            </div>
          ))}
        </div>
        <Link href="/shop?sale=true"><Button variant="rose">Shop the Sale</Button></Link>
      </Reveal>
    </section>
  );
}
