"use client";

import { useState, useMemo } from "react";
import Reveal from "@/components/ui/Reveal";
import ProductScrollRow from "@/components/product/ProductScrollRow";
import { Product } from "@/lib/types";

const textureColor: Record<string, string> = {
  dewy: "#C9A66B", satin: "#B76E79", rich: "#7A5C3E", silky: "#C9A66B",
  warm: "#7A5C3E", glossy: "#B76E79", velvet: "#8C4550", creamy: "#C9A66B",
  whipped: "#F1DFDA", floral: "#B76E79",
};

export default function ShopByFeel({ products }: { products: Product[] }) {
  const [active, setActive] = useState("dewy");
  const swatches = Object.keys(textureColor);
  const matches = useMemo(() => products.filter((p) => p.texture.includes(active)).slice(0, 10), [products, active]);

  return (
    <section className="max-w-7xl mx-auto px-5 sm:px-8 py-20">
      <Reveal className="mb-7">
        <p className="text-[12px] uppercase tracking-[0.25em] mb-2 font-body text-rosegold">Our signature finder</p>
        <h2 className="text-[28px] sm:text-[34px] leading-tight font-display text-espresso">Shop by feel, not just formula</h2>
      </Reveal>
      <div className="flex flex-wrap gap-2.5 mb-8">
        {swatches.map((t) => (
          <button
            key={t}
            onClick={() => setActive(t)}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-full text-[12px] tracking-wide transition-all font-body border ${
              active === t ? "bg-espresso text-ivory border-espresso" : "bg-ivory-deep text-espresso border-line"
            }`}
          >
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: textureColor[t] }} />
            {t}
          </button>
        ))}
      </div>
      {matches.length > 0 ? (
        <Reveal><ProductScrollRow products={matches} /></Reveal>
      ) : (
        <p className="text-[14px] font-body text-espresso-soft">More arriving in this finish soon.</p>
      )}
    </section>
  );
}
