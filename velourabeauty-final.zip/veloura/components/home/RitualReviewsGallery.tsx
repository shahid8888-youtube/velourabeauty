import Image from "next/image";
import { Instagram } from "lucide-react";
import Reveal from "@/components/ui/Reveal";
import { StarRating } from "@/components/ui/Badge";

const steps = [
  { n: "01", title: "Cleanse", desc: "Remove impurities without stripping the skin barrier." },
  { n: "02", title: "Treat", desc: "Layer serum for targeted hydration and repair overnight." },
  { n: "03", title: "Seal", desc: "Lock it in with cream to wake up to visibly softer skin." },
];

const reviews = [
  { name: "Amara O.", city: "Lahore", text: "The serum sank in within seconds and my skin looked lit from within by morning. Worth every rupee.", rating: 5 },
  { name: "Priya K.", city: "Karachi", text: "First luxury brand that actually feels made for South Asian skin tones. The highlight balm is unreal.", rating: 5 },
  { name: "Farah S.", city: "Islamabad", text: "Packaging alone feels like a gift. The lip duo lasted through an entire wedding without a touch-up.", rating: 4 },
];

const igImages = [
  "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=500&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?q=80&w=500&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1596462502278-27bfdc403348?q=80&w=500&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?q=80&w=500&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1586495777744-4413f21062fa?q=80&w=500&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=500&auto=format&fit=crop",
];

export function Ritual() {
  return (
    <section className="max-w-7xl mx-auto px-5 sm:px-8 py-20">
      <Reveal className="mb-7">
        <p className="text-[12px] uppercase tracking-[0.25em] mb-2 font-body text-rosegold">The three-step ritual</p>
        <h2 className="text-[28px] sm:text-[34px] leading-tight font-display text-espresso">How to layer for results</h2>
      </Reveal>
      <div className="grid md:grid-cols-3 gap-8">
        {steps.map((s, i) => (
          <Reveal key={s.n} delay={i * 120} className="pt-6 border-t border-line hover:-translate-y-1 transition-transform duration-500">
            <span className="font-display text-[13px] tracking-widest text-rosegold">{s.n}</span>
            <h3 className="font-display text-[22px] mt-2 text-espresso">{s.title}</h3>
            <p className="font-body text-[14px] mt-2 leading-relaxed text-espresso-soft">{s.desc}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function Reviews() {
  return (
    <section className="py-20 bg-ivory-deep">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <Reveal className="mb-7">
          <p className="text-[12px] uppercase tracking-[0.25em] mb-2 font-body text-rosegold">18,400+ reviews</p>
          <h2 className="text-[28px] sm:text-[34px] leading-tight font-display text-espresso">What our clients say</h2>
        </Reveal>
        <div className="grid md:grid-cols-3 gap-6">
          {reviews.map((r, i) => (
            <Reveal key={i} delay={i * 100} className="p-6 rounded-sm bg-ivory border border-line hover:shadow-xl transition-shadow duration-500">
              <StarRating rating={r.rating} />
              <p className="font-body text-[14px] leading-relaxed mt-4 text-espresso">&quot;{r.text}&quot;</p>
              <div className="flex items-center gap-3 mt-5">
                <span className="w-9 h-9 rounded-full flex items-center justify-center text-[12px] font-display bg-blush text-deeprose">
                  {r.name.split(" ").map((w) => w[0]).join("")}
                </span>
                <div>
                  <p className="font-display text-[13px] text-rosegold">{r.name}</p>
                  <p className="font-body text-[11px] text-espresso-soft">{r.city} · Verified buyer</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function InstagramGallery() {
  return (
    <section className="max-w-7xl mx-auto px-5 sm:px-8 py-20">
      <Reveal className="mb-7">
        <p className="text-[12px] uppercase tracking-[0.25em] mb-2 font-body text-rosegold">@veloura</p>
        <h2 className="text-[28px] sm:text-[34px] leading-tight font-display text-espresso">Tag us to be featured</h2>
      </Reveal>
      <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
        {igImages.map((src, i) => (
          <Reveal key={i} delay={i * 60} className="relative group overflow-hidden" style={{ aspectRatio: "1/1" }}>
            <Image src={src} alt="Instagram" fill sizes="200px" className="object-cover transition-transform duration-500 group-hover:scale-110" />
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-espresso/40">
              <Instagram size={20} className="text-ivory" />
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
