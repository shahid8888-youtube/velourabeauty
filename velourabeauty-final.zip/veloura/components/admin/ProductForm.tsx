"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { productSchema, ProductFormValues, CATEGORY_OPTIONS } from "@/lib/validations/product";
import Button from "@/components/ui/Button";
import { UploadCloud, X, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function ProductForm({ defaultValues }: { defaultValues?: Partial<ProductFormValues> & { id?: string } }) {
  const router = useRouter();
  const [images, setImages] = useState<string[]>(defaultValues?.images || []);
  const [manualUrl, setManualUrl] = useState("");
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<ProductFormValues>({
    resolver: zodResolver(productSchema),
    defaultValues: { isPublished: true, isBestseller: false, brand: "Velourabeauty", ...defaultValues },
  });

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        const base64 = await fileToBase64(file);
        const res = await fetch("/api/upload", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ file: base64 }),
        });
        const json = await res.json();
        if (json.url) {
          setImages((prev) => {
            const next = [...prev, json.url];
            setValue("images", next);
            return next;
          });
        } else {
          toast.error(json.error || "Image upload failed");
        }
      }
    } finally {
      setUploading(false);
    }
  };

  const removeImage = (url: string) => {
    setImages((prev) => {
      const next = prev.filter((i) => i !== url);
      setValue("images", next);
      return next;
    });
  };

  const [formErrorSummary, setFormErrorSummary] = useState<string[]>([]);

  const onInvalid = (formErrors: typeof errors) => {
    const messages = Object.entries(formErrors).map(
      ([field, err]) => `${field}: ${(err as any)?.message || "invalid value"}`
    );
    setFormErrorSummary(messages.length ? messages : ["Something is blocking submission — please check every field above."]);
    toast.error("Please fix the highlighted fields below.");
  };

  const onSubmit = async (values: ProductFormValues) => {
    setFormErrorSummary([]);
    setSubmitting(true);
    try {
      const isEdit = Boolean(defaultValues?.id);
      const res = await fetch(isEdit ? `/api/products/${defaultValues!.id}` : "/api/products", {
        method: isEdit ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...values, images }),
      });
      const json = await res.json();
      if (!res.ok) {
        const msg = json.error?.formErrors?.[0] || json.error || "Something went wrong";
        setFormErrorSummary([msg]);
        toast.error(msg);
        return;
      }
      toast.success(isEdit ? "Product updated" : "Product added to your store");
      router.push("/admin/products");
      router.refresh();
    } catch (err) {
      setFormErrorSummary(["Network or server error — the site couldn't be reached. Check your internet connection and try again."]);
      toast.error("Could not reach the server.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit, onInvalid)} className="max-w-2xl space-y-6">
      {formErrorSummary.length > 0 && (
        <div className="p-4 rounded-sm bg-blush border border-deeprose">
          <p className="font-body text-[13px] font-semibold text-deeprose mb-1.5">Please fix the following:</p>
          <ul className="list-disc list-inside space-y-0.5">
            {formErrorSummary.map((msg, i) => (
              <li key={i} className="font-body text-[12.5px] text-deeprose">{msg}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Images */}
      <div>
        <label className="block text-[13px] font-body font-semibold text-espresso mb-2">Product Images</label>
        <div className="flex flex-wrap gap-3">
          {images.map((url) => (
            <div key={url} className="relative w-24 h-24 rounded-sm overflow-hidden border border-line">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={url} alt="Product" className="w-full h-full object-cover" />
              <button type="button" onClick={() => removeImage(url)} className="absolute top-1 right-1 w-5 h-5 rounded-full bg-espresso/80 flex items-center justify-center">
                <X size={12} color="#fff" />
              </button>
            </div>
          ))}
          <label className="w-24 h-24 rounded-sm border border-dashed border-line flex flex-col items-center justify-center cursor-pointer text-espresso-soft hover:border-rosegold transition-colors">
            {uploading ? <Loader2 size={18} className="animate-spin" /> : <UploadCloud size={18} />}
            <span className="text-[10px] mt-1 font-body">{uploading ? "Uploading" : "Add photo"}</span>
            <input type="file" accept="image/*" multiple className="hidden" onChange={handleFileChange} disabled={uploading} />
          </label>
        </div>
        {errors.images && <p className="text-[12px] text-deeprose mt-1 font-body">{errors.images.message as string}</p>}

        {/* Fallback: paste an image link directly (useful if Cloudinary upload isn't working yet) */}
        <div className="mt-3 flex items-center gap-2">
          <input
            type="url"
            value={manualUrl}
            onChange={(e) => setManualUrl(e.target.value)}
            placeholder="Or paste an image link here (e.g. from imgbb.com)"
            className="input flex-1"
          />
          <button
            type="button"
            onClick={() => {
              if (!manualUrl) return;
              setImages((prev) => {
                const next = [...prev, manualUrl];
                setValue("images", next);
                return next;
              });
              setManualUrl("");
            }}
            className="px-4 py-2.5 text-[12px] font-body uppercase tracking-wide bg-espresso text-ivory whitespace-nowrap"
          >
            Add Link
          </button>
        </div>
        <p className="text-[11px] font-body text-espresso-soft mt-1">
          Tip: open imgbb.com on your phone, upload your photo, copy the &quot;Direct link&quot;, and paste it above.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Field label="Product Name" error={errors.name?.message}>
          <input {...register("name")} className="input" placeholder="e.g. Rose Glow Facial Serum" />
        </Field>
        <Field label="SKU" error={errors.sku?.message}>
          <input {...register("sku")} className="input" placeholder="e.g. VB-SK-0001" />
        </Field>
        <Field label="Category" error={errors.category?.message}>
          <select {...register("category")} className="input">
            {CATEGORY_OPTIONS.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
        </Field>
        <Field label="Subcategory (optional)">
          <input {...register("subcategory")} className="input" placeholder="e.g. Serums" />
        </Field>
        <Field label="Price ($)" error={errors.price?.message}>
          <input type="number" step="0.01" {...register("price")} className="input" placeholder="45.00" />
        </Field>
        <Field label="Compare-at price (optional)">
          <input type="number" step="0.01" {...register("oldPrice")} className="input" placeholder="60.00" />
        </Field>
        <Field label="Stock quantity" error={errors.stock?.message}>
          <input type="number" {...register("stock")} className="input" placeholder="20" />
        </Field>
      </div>

      <Field label="Description" error={errors.description?.message}>
        <textarea {...register("description")} rows={4} className="input" placeholder="Describe what this product does and who it's for..." />
      </Field>
      <Field label="Benefits (one per line)">
        <textarea {...register("benefits")} rows={3} className="input" placeholder={"Brightens skin\nReduces fine lines"} />
      </Field>
      <Field label="Ingredients (one per line)">
        <textarea {...register("ingredients")} rows={3} className="input" placeholder={"Hyaluronic Acid\nVitamin C"} />
      </Field>
      <Field label="How to use (one step per line)">
        <textarea {...register("usage")} rows={3} className="input" placeholder={"Apply to clean skin\nUse morning and night"} />
      </Field>

      <div className="flex items-center gap-6">
        <label className="flex items-center gap-2 text-[13px] font-body text-espresso">
          <input type="checkbox" {...register("isPublished")} defaultChecked /> Published (visible on store)
        </label>
        <label className="flex items-center gap-2 text-[13px] font-body text-espresso">
          <input type="checkbox" {...register("isBestseller")} /> Mark as Bestseller
        </label>
      </div>

      <Button type="submit" variant="solid" size="lg" disabled={submitting}>
        {submitting ? "Saving..." : defaultValues?.id ? "Update Product" : "Add Product to Store"}
      </Button>

      <style jsx global>{`
        .input {
          width: 100%;
          padding: 10px 14px;
          font-size: 14px;
          font-family: var(--font-manrope);
          background: #fff;
          border: 1px solid #E4D9CE;
          border-radius: 2px;
          color: #2A211D;
        }
        .input:focus {
          outline: none;
          border-color: #B76E79;
        }
      `}</style>
    </form>
  );
}

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-[13px] font-body font-semibold text-espresso mb-1.5">{label}</label>
      {children}
      {error && <p className="text-[12px] text-deeprose mt-1 font-body">{error}</p>}
    </div>
  );
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
