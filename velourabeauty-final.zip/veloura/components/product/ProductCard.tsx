"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Heart, ShoppingBag, Check, Flame } from "lucide-react";
import { Product } from "@/lib/types";
import { Badge, StarRating } from "@/components/ui/Badge";
import { useCartStore } from "@/lib/store/cart-store";
import { toast } from "sonner";

const textureColor: Record<string, string> = {
  dewy: "#C9A66B", lightweight: "#F1DFDA", satin: "#B76E79", buildable: "#8C4550",
  rich: "#7A5C3E", cushiony: "#F3EDE4", sheer: "#F1DFDA", silky: "#C9A66B",
  "non-greasy": "#B76E79", warm: "#7A5C3E", woody: "#2A211D", foamy: "#F1DFDA",
  gentle: "#C9A66B", watery: "#F3EDE4", glossy: "#B76E79", hydrating: "#C9A66B",
  velvet: "#8C4550", blendable: "#B76E79", pigmented: "#8C4550",
  waterproof: "#2A211D", "smudge-proof": "#5C4F49", creamy: "#C9A66B",
  whipped: "#F1DFDA", floral: "#B76E79", musky: "#7A5C3E", smooth: "#C9A66B",
  cooling: "#F3EDE4", soft: "#F1DFDA", precise: "#5C4F49", "fast-absorbing": "#C9A66B",
  "non-comedogenic": "#F1DFDA", "non-stripping": "#F3EDE4", nourishing: "#7A5C3E",
};

export default function ProductCard({ product }: { product: Product }) {
  const [wish, setWish] = useState(false);
  const [added, setAdded] = useState(false);
  const addItem = useCartStore((s) => s.addItem);

  const handleAdd = () => {
    addItem(product, product.variants[0].id, 1);
    setAdded(true);
    toast.success(`${product.name} added to bag`);
    setTimeout(() => setAdded(false), 1800);
  };

  return (
    <div className="group relative flex-shrink-0 w-[260px] sm:w-[280px]">
      <Link href={`/product/${product.slug}`}>
        <div
          className="relative overflow-hidden rounded-sm bg-ivory-deep transition-shadow duration-500 group-hover:shadow-2xl"
          style={{ aspectRatio: "4/5" }}
        >
          <Image
            src={product.images[0]}
            alt={product.name}
            fill
            sizes="280px"
            className="object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div className="absolute top-3 left-3 flex flex-col gap-1.5 items-start">
            {(product.isNew || product.isBestseller || product.isTrending || product.oldPrice) && (
              <Badge tone={product.isNew ? "gold" : product.isBestseller ? "dark" : "rose"}>
                {product.isNew ? "New" : product.isBestseller ? "Bestseller" : product.isTrending ? "Trending" : "Sale"}
              </Badge>
            )}
            {product.stock > 0 && product.stock <= 6 && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-body bg-deeprose/90 text-ivory">
                <Flame size={10} /> Only {product.stock} left
              </span>
            )}
          </div>
          <button
            onClick={(e) => { e.preventDefault(); setWish(!wish); }}
            aria-label="Add to wishlist"
            className="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center bg-ivory/90 hover:scale-110 transition-all"
          >
            <Heart size={15} fill={wish ? "#8C4550" : "none"} color="#8C4550" strokeWidth={1.75} />
          </button>
          <button
            onClick={(e) => { e.preventDefault(); handleAdd(); }}
            className={`absolute bottom-0 left-0 right-0 py-3 text-xs tracking-[0.15em] uppercase font-body translate-y-full group-hover:translate-y-0 transition-all duration-300 flex items-center justify-center gap-2 ${
              added ? "bg-[#5C8A6B]" : "bg-espresso"
            } text-ivory`}
          >
            {added ? (<><Check size={14} /> Added to bag</>) : (<><ShoppingBag size={14} /> Add to bag</>)}
          </button>
        </div>
        <div className="pt-3">
          <p className="text-[11px] uppercase tracking-widest font-body text-rosegold">{product.brand}</p>
          <h3 className="mt-0.5 text-[15px] font-display text-espresso">{product.name}</h3>
          {(product.rating ?? 0) > 0 && (
            <div className="flex items-center gap-2 mt-1">
              <StarRating rating={product.rating!} />
              <span className="text-[11px] font-body text-espresso-soft">({product.reviewCount ?? 0})</span>
            </div>
          )}
          <div className="flex items-baseline gap-2 mt-1.5">
            <span className="font-body font-semibold text-[15px] text-espresso">${product.price}</span>
            {product.oldPrice && <span className="font-body text-[12px] line-through text-espresso-soft">${product.oldPrice}</span>}
          </div>
          {product.texture && product.texture.length > 0 && (
            <div className="flex items-center gap-1.5 mt-2">
              {product.texture.map((t, i) => (
                <span key={i} title={t} className="w-2.5 h-2.5 rounded-full ring-1 ring-line" style={{ background: textureColor[t] || "#C9A66B" }} />
              ))}
              <span className="text-[10px] uppercase tracking-widest ml-1 font-body text-espresso-soft">{product.texture.join(" · ")}</span>
            </div>
          )}
          {(product.soldToday ?? 0) > 0 && (
            <p className="text-[10.5px] mt-1.5 font-body text-deeprose">🔥 {product.soldToday} sold today</p>
          )}
        </div>
      </Link>
    </div>
  );
}
