"use client";

import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Product } from "@/lib/types";
import ProductCard from "./ProductCard";

export default function ProductScrollRow({ products }: { products: Product[] }) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => ref.current?.scrollBy({ left: dir * 300, behavior: "smooth" });

  return (
    <div className="relative">
      <div ref={ref} className="flex gap-5 overflow-x-auto pb-2 scroll-smooth no-scrollbar">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
      <button
        onClick={() => scroll(-1)}
        aria-label="Scroll left"
        className="hidden md:flex absolute -left-4 top-1/3 w-9 h-9 rounded-full items-center justify-center shadow-md bg-ivory border border-line hover:scale-110 transition-transform"
      >
        <ChevronLeft size={16} />
      </button>
      <button
        onClick={() => scroll(1)}
        aria-label="Scroll right"
        className="hidden md:flex absolute -right-4 top-1/3 w-9 h-9 rounded-full items-center justify-center shadow-md bg-ivory border border-line hover:scale-110 transition-transform"
      >
        <ChevronRight size={16} />
      </button>
    </div>
  );
}
