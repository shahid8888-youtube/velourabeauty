import Link from "next/link";

const cols = [
  {
    title: "Shop",
    links: [
      { label: "Skincare", href: "/shop/skincare" },
      { label: "Makeup", href: "/shop/makeup" },
      { label: "Haircare", href: "/shop/haircare" },
      { label: "Fragrance", href: "/shop/fragrance" },
      { label: "Gift Sets", href: "/shop" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About Veloura", href: "/about" },
      { label: "Journal", href: "/blog" },
      { label: "Contact Us", href: "/contact" },
    ],
  },
  {
    title: "Support",
    links: [
      { label: "Order Tracking", href: "/track-order" },
      { label: "Shipping Policy", href: "/shipping-policy" },
      { label: "Refund Policy", href: "/refund-policy" },
      { label: "Terms & Conditions", href: "/terms" },
      { label: "Privacy Policy", href: "/privacy-policy" },
      { label: "FAQ", href: "/faq" },
    ],
  },
];

export default function SiteFooter() {
  return (
    <footer className="bg-ivory-deep border-t border-line">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-16 grid md:grid-cols-4 gap-10">
        <div>
          <span className="font-display text-[22px] tracking-[0.08em] text-espresso">VELOURA</span>
          <p className="font-body text-[13px] mt-4 leading-relaxed max-w-xs text-espresso-soft">
            Luxury skincare and cosmetics formulated for every skin tone, shipped worldwide.
          </p>
        </div>
        {cols.map((c) => (
          <div key={c.title}>
            <h4 className="font-body text-[12px] uppercase tracking-widest mb-4 text-espresso">{c.title}</h4>
            <ul className="space-y-2.5">
              {c.links.map((l) => (
                <li key={l.label}>
                  <Link href={l.href} className="font-body text-[13.5px] text-espresso-soft hover:underline">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-line">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="font-body text-[12px] text-espresso-soft">© {new Date().getFullYear()} Veloura. All rights reserved.</p>
          <p className="font-body text-[12px] text-espresso-soft">Privacy · Terms · Sitemap</p>
        </div>
      </div>
    </footer>
  );
}
