"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Search, Heart, ShoppingBag, User, Menu, X } from "lucide-react";
import { useCartStore } from "@/lib/store/cart-store";

const links = [
  { label: "Skincare", href: "/shop/skincare" },
  { label: "Makeup", href: "/shop/makeup" },
  { label: "Haircare", href: "/shop/haircare" },
  { label: "Fragrance", href: "/shop/fragrance" },
  { label: "Gifting", href: "/shop" },
  { label: "Journal", href: "/blog" },
];

export default function SiteHeader() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const cartCount = useCartStore((s) => s.items.reduce((sum, i) => sum + i.quantity, 0));

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <div className="text-center py-2.5 text-[12px] tracking-wide font-body bg-espresso text-ivory">
        Free worldwide shipping on orders over $75 — Cash on delivery &amp; WhatsApp ordering available in Pakistan
      </div>
      <header
        className={`sticky top-0 z-40 bg-ivory/95 backdrop-blur-md border-b border-line transition-shadow ${
          scrolled ? "shadow-[0_4px_20px_rgba(42,33,29,0.06)]" : ""
        }`}
      >
        <div className="max-w-7xl mx-auto px-5 sm:px-8 flex items-center justify-between h-[76px]">
          <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
          <Link href="/" className="flex-1 md:flex-none text-center md:text-left">
            <span className="font-display text-[26px] tracking-[0.08em] text-espresso">VELOURA</span>
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            {links.map((l) => (
              <Link
                key={l.label}
                href={l.href}
                className="text-[13px] tracking-wide font-body text-espresso-soft hover:text-espresso transition-colors"
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/search" aria-label="Search"><Search size={19} className="hover:scale-110 transition-transform" /></Link>
            <Link href="/account" aria-label="Account" className="hidden sm:block"><User size={19} className="hover:scale-110 transition-transform" /></Link>
            <Link href="/wishlist" aria-label="Wishlist" className="hidden sm:block"><Heart size={19} className="hover:scale-110 transition-transform" /></Link>
            <Link href="/cart" aria-label="Cart" className="relative hover:scale-110 transition-transform">
              <ShoppingBag size={19} />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 w-4 h-4 rounded-full bg-rosegold text-ivory text-[9px] flex items-center justify-center animate-pulseGlow">
                  {cartCount}
                </span>
              )}
            </Link>
          </div>
        </div>
        {menuOpen && (
          <div className="md:hidden px-5 pb-5 flex flex-col gap-3 border-t border-line">
            {links.map((l) => (
              <Link key={l.label} href={l.href} className="text-sm pt-3 font-body text-espresso" onClick={() => setMenuOpen(false)}>
                {l.label}
              </Link>
            ))}
          </div>
        )}
      </header>
    </>
  );
}
