import type { Metadata } from "next";
import Link from "next/link";
import { PackageOpen } from "lucide-react";
import Hero from "@/components/home/Hero";
import { TrustBar, Categories } from "@/components/home/TrustAndCategories";
import { BestSellers, FlashSale } from "@/components/home/BestSellersAndSale";
import { Ritual, Reviews, InstagramGallery } from "@/components/home/RitualReviewsGallery";
import { Newsletter, FAQ } from "@/components/home/NewsletterAndFAQ";
import LiveNotification from "@/components/home/LiveNotification";
import Button from "@/components/ui/Button";
import { prisma } from "@/lib/prisma";
import { Product } from "@/lib/types";

export const metadata: Metadata = {
  title: "Luxury Beauty, Undiluted",
  description:
    "Shop Velourabeauty's skincare, makeup, haircare and fragrance — dermatologist tested, cruelty-free, and formulated for every skin tone. Free worldwide shipping, COD in Pakistan.",
};

export const dynamic = "force-dynamic";

// Maps a database product (your real product) into the shape the storefront
// components expect. No demo/fake data — everything here comes from what
// you add in /admin/products/new.
function mapDbProduct(p: any): Product {
  const avgRating = p.reviews?.length
    ? p.reviews.reduce((sum: number, r: any) => sum + r.rating, 0) / p.reviews.length
    : 0;
  return {
    id: p.id,
    sku: p.sku,
    slug: p.slug,
    name: p.name,
    brand: p.brand,
    category: p.category,
    subcategory: p.subcategory || "",
    price: Number(p.price),
    oldPrice: p.oldPrice ? Number(p.oldPrice) : undefined,
    currency: p.currency,
    stock: p.stock,
    rating: avgRating,
    reviewCount: p.reviews?.length || 0,
    images: p.images?.length ? p.images.map((i: any) => i.url) : ["/placeholder-product.jpg"],
    description: p.description,
    benefits: p.benefits,
    ingredients: p.ingredients,
    usage: p.usage,
    variants: p.variants || [],
    tags: p.tags,
    isBestseller: p.isBestseller,
    isNew: p.isNew,
    createdAt: p.createdAt?.toISOString?.() || new Date().toISOString(),
  };
}

export default async function HomePage() {
  let products: Product[] = [];
  let dbConnected = true;

  try {
    const dbProducts = await prisma.product.findMany({
      where: { isPublished: true },
      include: { images: { orderBy: { position: "asc" } }, variants: true, reviews: true },
      orderBy: { createdAt: "desc" },
      take: 20,
    });
    products = dbProducts.map(mapDbProduct);
  } catch {
    dbConnected = false;
  }

  const bestsellers = products.filter((p) => p.isBestseller);

  return (
    <>
      <Hero />
      <TrustBar />
      <Categories />

      {!dbConnected && (
        <div className="max-w-3xl mx-auto px-5 py-10 text-center">
          <p className="font-body text-[13px] text-espresso-soft">
            Database not connected yet — set <code>DATABASE_URL</code> in <code>.env.local</code> and run{" "}
            <code>npx prisma migrate dev</code> to start listing your real products here.
          </p>
        </div>
      )}

      {dbConnected && products.length === 0 && (
        <div className="max-w-3xl mx-auto px-5 sm:px-8 py-20 text-center">
          <PackageOpen size={36} className="mx-auto text-espresso-soft mb-4" />
          <h2 className="font-display text-[26px] text-espresso mb-2">Your store is ready — add your first product</h2>
          <p className="font-body text-[14px] text-espresso-soft mb-6 max-w-md mx-auto">
            This homepage pulls directly from your own catalog. Nothing here is placeholder data —
            once you add a product in the admin panel, it appears right here for every visitor.
          </p>
          <Link href="/admin/products/new"><Button variant="solid">Add Your First Product</Button></Link>
        </div>
      )}

      {products.length > 0 && (
        <BestSellers products={bestsellers.length ? bestsellers : products.slice(0, 10)} />
      )}
      {products.length > 0 && <FlashSale />}

      <Ritual />
      {products.length > 0 && <Reviews />}
      <InstagramGallery />
      <Newsletter />
      <FAQ />
      {products.length > 0 && <LiveNotification />}
    </>
  );
}
