import Link from "next/link";
import Image from "next/image";
import { prisma } from "@/lib/prisma";
import { Plus, PackageOpen } from "lucide-react";
import Button from "@/components/ui/Button";
import DeleteProductButton from "@/components/admin/DeleteProductButton";

export const dynamic = "force-dynamic";

export default async function AdminProductsPage() {
  let products: any[] = [];
  let dbError = false;

  try {
    products = await prisma.product.findMany({
      include: { images: true },
      orderBy: { createdAt: "desc" },
    });
  } catch {
    dbError = true;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-[28px] text-espresso">Your Products</h1>
          <p className="font-body text-[13px] text-espresso-soft mt-1">
            Products you add here appear live on velourabeauty.com immediately.
          </p>
        </div>
        <Link href="/admin/products/new">
          <Button variant="solid" size="sm"><Plus size={15} /> Add Product</Button>
        </Link>
      </div>

      {dbError && (
        <div className="p-4 rounded-sm bg-blush text-deeprose text-[13px] font-body mb-6">
          Database isn&apos;t connected yet. Set <code>DATABASE_URL</code> in <code>.env.local</code> and run{" "}
          <code>npx prisma migrate dev</code>, then this page will list your real products.
        </div>
      )}

      {products.length === 0 && !dbError && (
        <div className="border border-dashed border-line rounded-sm p-16 text-center">
          <PackageOpen size={32} className="mx-auto text-espresso-soft mb-3" />
          <p className="font-display text-[18px] text-espresso mb-1">No products yet</p>
          <p className="font-body text-[13px] text-espresso-soft mb-5">Add your first real product to start selling.</p>
          <Link href="/admin/products/new">
            <Button variant="solid" size="sm">Add Your First Product</Button>
          </Link>
        </div>
      )}

      {products.length > 0 && (
        <div className="border border-line rounded-sm overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-ivory-deep">
              <tr>
                <th className="px-4 py-3 text-[11px] uppercase tracking-wide font-body text-espresso-soft">Product</th>
                <th className="px-4 py-3 text-[11px] uppercase tracking-wide font-body text-espresso-soft">Category</th>
                <th className="px-4 py-3 text-[11px] uppercase tracking-wide font-body text-espresso-soft">Price</th>
                <th className="px-4 py-3 text-[11px] uppercase tracking-wide font-body text-espresso-soft">Stock</th>
                <th className="px-4 py-3 text-[11px] uppercase tracking-wide font-body text-espresso-soft">Status</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id} className="border-t border-line">
                  <td className="px-4 py-3 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-sm overflow-hidden bg-ivory-deep relative flex-shrink-0">
                      {p.images[0] && <Image src={p.images[0].url} alt={p.name} fill className="object-cover" />}
                    </div>
                    <span className="font-body text-[13.5px] text-espresso">{p.name}</span>
                  </td>
                  <td className="px-4 py-3 font-body text-[13px] text-espresso-soft">{p.category}</td>
                  <td className="px-4 py-3 font-body text-[13px] text-espresso">${p.price.toString()}</td>
                  <td className="px-4 py-3 font-body text-[13px] text-espresso">{p.stock}</td>
                  <td className="px-4 py-3">
                    <span className={`text-[11px] px-2 py-0.5 rounded-full font-body ${p.isPublished ? "bg-[#E4EFE6] text-[#3E6B4A]" : "bg-ivory-deep text-espresso-soft"}`}>
                      {p.isPublished ? "Live" : "Draft"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Link href={`/admin/products/${p.id}/edit`} className="text-[12px] font-body text-rosegold hover:underline mr-4">Edit</Link>
                    <DeleteProductButton productId={p.id} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
