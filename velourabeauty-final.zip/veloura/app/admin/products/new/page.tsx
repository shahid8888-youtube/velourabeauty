import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import ProductForm from "@/components/admin/ProductForm";

export default function NewProductPage() {
  return (
    <div>
      <Link href="/admin/products" className="inline-flex items-center gap-1.5 text-[13px] font-body text-espresso-soft hover:text-espresso mb-6">
        <ArrowLeft size={14} /> Back to products
      </Link>
      <h1 className="font-display text-[28px] text-espresso mb-1">Add a Product</h1>
      <p className="font-body text-[13px] text-espresso-soft mb-8">
        This is your real catalog — fill this in with your own product, upload real photos, and it goes live on velourabeauty.com.
      </p>
      <ProductForm />
    </div>
  );
}
