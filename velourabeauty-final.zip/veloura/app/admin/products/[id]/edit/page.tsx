import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/prisma";
import ProductForm from "@/components/admin/ProductForm";

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: { images: true },
  });
  if (!product) notFound();

  return (
    <div>
      <Link href="/admin/products" className="inline-flex items-center gap-1.5 text-[13px] font-body text-espresso-soft hover:text-espresso mb-6">
        <ArrowLeft size={14} /> Back to products
      </Link>
      <h1 className="font-display text-[28px] text-espresso mb-1">Edit Product</h1>
      <p className="font-body text-[13px] text-espresso-soft mb-8">Update details, price, stock, or photos.</p>
      <ProductForm
        defaultValues={{
          id: product.id,
          name: product.name,
          brand: product.brand,
          category: product.category as any,
          subcategory: product.subcategory || "",
          sku: product.sku,
          price: Number(product.price),
          oldPrice: product.oldPrice ? Number(product.oldPrice) : undefined,
          stock: product.stock,
          description: product.description,
          benefits: product.benefits.join("\n"),
          ingredients: product.ingredients.join("\n"),
          usage: product.usage.join("\n"),
          images: product.images.map((i) => i.url),
          isPublished: product.isPublished,
          isBestseller: product.isBestseller,
        }}
      />
    </div>
  );
}
