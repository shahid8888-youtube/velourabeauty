import Link from "next/link";
import { LayoutDashboard, Package, ShoppingCart, Users, Tag, Settings } from "lucide-react";

const navItems = [
  { label: "Dashboard", href: "/admin", icon: LayoutDashboard },
  { label: "Products", href: "/admin/products", icon: Package },
  { label: "Orders", href: "/admin/orders", icon: ShoppingCart },
  { label: "Customers", href: "/admin/customers", icon: Users },
  { label: "Coupons", href: "/admin/coupons", icon: Tag },
  { label: "Settings", href: "/admin/settings", icon: Settings },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-ivory flex">
      <aside className="w-64 bg-espresso text-ivory flex-shrink-0 hidden md:flex flex-col">
        <div className="px-6 py-6 border-b border-ivory/10">
          <span className="font-display text-[20px] tracking-[0.06em]">VELOURA</span>
          <p className="text-[11px] font-body text-champagne mt-0.5">Admin Panel</p>
        </div>
        <nav className="flex-1 py-4">
          {navItems.map(({ label, href, icon: Icon }) => (
            <Link key={label} href={href} className="flex items-center gap-3 px-6 py-3 text-[13.5px] font-body text-ivory/85 hover:bg-ivory/5 hover:text-ivory transition-colors">
              <Icon size={17} />
              {label}
            </Link>
          ))}
        </nav>
        <div className="px-6 py-4 border-t border-ivory/10">
          <Link href="/" className="text-[12px] font-body text-champagne hover:underline">← Back to storefront</Link>
        </div>
      </aside>
      <main className="flex-1 min-w-0">
        <div className="px-6 sm:px-10 py-8 max-w-5xl mx-auto">{children}</div>
      </main>
    </div>
  );
}
