import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { Package, ShoppingCart, DollarSign, PlusCircle } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  let productCount = 0;
  try {
    productCount = await prisma.product.count();
  } catch {
    // DB not connected yet
  }

  const stats = [
    { label: "Your Products", value: productCount, icon: Package, href: "/admin/products" },
    { label: "Orders", value: 0, icon: ShoppingCart, href: "/admin/orders" },
    { label: "Revenue", value: "$0.00", icon: DollarSign, href: "/admin/orders" },
  ];

  return (
    <div>
      <h1 className="font-display text-[28px] text-espresso mb-1">Welcome back, Shahid</h1>
      <p className="font-body text-[13px] text-espresso-soft mb-8">Here's what's happening with Velourabeauty.</p>

      <div className="grid sm:grid-cols-3 gap-4 mb-10">
        {stats.map(({ label, value, icon: Icon, href }) => (
          <Link key={label} href={href} className="p-5 border border-line rounded-sm bg-white hover:shadow-md transition-shadow">
            <Icon size={18} className="text-rosegold mb-3" />
            <p className="font-display text-[24px] text-espresso">{value}</p>
            <p className="font-body text-[12px] text-espresso-soft">{label}</p>
          </Link>
        ))}
      </div>

      {productCount === 0 && (
        <div className="p-6 border border-dashed border-line rounded-sm text-center">
          <p className="font-display text-[17px] text-espresso mb-1">Your store is empty</p>
          <p className="font-body text-[13px] text-espresso-soft mb-4">Add your first real product to start selling on velourabeauty.com.</p>
          <Link href="/admin/products/new" className="inline-flex items-center gap-1.5 text-[13px] font-body text-rosegold hover:underline">
            <PlusCircle size={15} /> Add a product
          </Link>
        </div>
      )}
    </div>
  );
}
