import type { Metadata } from "next";
import { Fraunces, Manrope } from "next/font/google";
import "./globals.css";
import { Toaster } from "sonner";
import SiteHeader from "@/components/layout/SiteHeader";
import SiteFooter from "@/components/layout/SiteFooter";
import WhatsAppFloat from "@/components/layout/WhatsAppFloat";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  weight: ["300", "400", "500", "600"],
  style: ["normal", "italic"],
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://velourabeauty.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Veloura — Luxury Beauty, Undiluted",
    template: "%s | Veloura",
  },
  description:
    "Veloura is a luxury beauty house offering skincare, makeup, haircare, fragrance and body care formulated for every skin tone. Free worldwide shipping, cash on delivery in Pakistan.",
  keywords: [
    "luxury beauty", "skincare", "makeup", "Veloura", "Pakistan beauty store",
    "cosmetics online", "COD beauty products",
  ],
  openGraph: {
    type: "website",
    siteName: "Veloura",
    title: "Veloura — Luxury Beauty, Undiluted",
    description: "Luxury skincare and cosmetics formulated for every skin tone. Shop worldwide, COD available in Pakistan.",
    url: siteUrl,
    images: [{ url: "/og-image.jpg", width: 1200, height: 630, alt: "Veloura" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Veloura — Luxury Beauty, Undiluted",
    description: "Luxury skincare and cosmetics formulated for every skin tone.",
  },
  robots: { index: true, follow: true },
  alternates: { canonical: siteUrl },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${fraunces.variable} ${manrope.variable}`}>
      <body className="font-body bg-ivory text-espresso antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "Veloura",
              url: siteUrl,
              logo: `${siteUrl}/logo.png`,
              sameAs: [
                "https://instagram.com/veloura",
                "https://facebook.com/veloura",
              ],
            }),
          }}
        />
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
        <WhatsAppFloat />
        <Toaster position="bottom-left" richColors />
      </body>
    </html>
  );
}
