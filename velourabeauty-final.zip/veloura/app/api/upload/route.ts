import { NextRequest, NextResponse } from "next/server";
import { v2 as cloudinary } from "cloudinary";

cloudinary.config({
  cloud_name: process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// POST /api/upload — stores product photos on Cloudinary.
// Required on Vercel (and any serverless host) because local disk storage
// does not persist between requests/deployments there.
export async function POST(req: NextRequest) {
  try {
    const { file } = await req.json();
    if (!file) return NextResponse.json({ error: "No file provided" }, { status: 400 });

    const result = await cloudinary.uploader.upload(file, {
      folder: "velourabeauty/products",
      transformation: [{ width: 1200, height: 1500, crop: "fill" }, { quality: "auto" }, { fetch_format: "auto" }],
    });

    return NextResponse.json({ url: result.secure_url });
  } catch (err) {
    console.error("Cloudinary upload error:", err);
    return NextResponse.json(
      { error: "Upload failed. Check NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET in your environment variables." },
      { status: 500 }
    );
  }
}
